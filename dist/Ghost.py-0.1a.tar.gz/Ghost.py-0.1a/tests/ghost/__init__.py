from ghost import Ghost
from test import GhostTestCase